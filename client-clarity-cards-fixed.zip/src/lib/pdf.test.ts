import { describe, it, expect } from 'vitest';
import { sanitizeFilePart, stripEmojis } from './pdf';

describe('sanitizeFilePart', () => {
  it('removes non-alphanumeric characters and collapses underscores', () => {
    const input = 'Hello!!!   World???';
    const result = sanitizeFilePart(input);
    expect(result).toBe('hello_world');
  });
});

describe('stripEmojis', () => {
  it('removes emojis and residual spaces', () => {
    const input = '  Hello 🌍  World 😀  ';
    const result = stripEmojis(input);
    expect(result).toBe('Hello World');
  });
});
