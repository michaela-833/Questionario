import type { SupabaseClient } from "@supabase/supabase-js";
import { supabase as connectedClient } from "@/integrations/supabase/client";

let client: SupabaseClient | null = connectedClient ?? null;

export function getSupabaseClient(): SupabaseClient | null {
  return client;
}

export async function uploadPdfToStorage(file: Blob, path: string): Promise<string> {
  const supabase = getSupabaseClient();
  if (!supabase) throw new Error("Supabase non è configurato. Collega il progetto dalle impostazioni Supabase e riprova.");

  const bucket = "questionari"; // assicurati che esista e sia pubblico
  const { error } = await supabase.storage.from(bucket).upload(path, file, {
    cacheControl: "3600",
    upsert: true,
    contentType: "application/pdf",
  });
  if (error) throw error;

  const { data } = supabase.storage.from(bucket).getPublicUrl(path);
  if (!data?.publicUrl) throw new Error("Impossibile ottenere l'URL pubblico del PDF.");
  return data.publicUrl;
}
