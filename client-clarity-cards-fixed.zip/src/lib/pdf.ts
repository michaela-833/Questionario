import { jsPDF } from "jspdf";
import { Note, Question } from "@/types/questionnaire";

export interface UserData {
  name: string;
  company: string;
}

export function sanitizeFilePart(value: string) {
  return value
    .toLowerCase()
    .replace(/[^a-z0-9-_]+/gi, "_")
    .replace(/_+/g, "_")
    .replace(/^_|_$/g, "");
}

export function stripEmojis(text: string) {
  return text
    .replace(/[\u2700-\u27BF]|[\uE000-\uF8FF]|[\uD83C-\uDBFF\uDC00-\uDFFF]|[\u2011-\u26FF]|[\uFE0F]|[\u200D]|[\u{1F300}-\u{1F9FF}]/gu, "")
    .replace(/\s+/g, " ")
    .trim();
}

export async function generateQuestionnairePdf(
  questions: Question[],
  answers: Record<string, string | string[] | Record<string, string>>,
  notes: Note[],
  user: UserData
): Promise<{ blob: Blob; fileName: string }> {
  const doc = new jsPDF({ unit: "pt", format: "a4" });
  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 48;
  let y = margin;

  const primary = "#1A1A2E"; // header text
  const accent = "#FF1493"; // fuchsia underline

  // Header
  doc.setFont("helvetica", "bold");
  doc.setFontSize(18);
  doc.setTextColor(primary);
  doc.text("QUESTIONARIO TECNICO-OPERATIVO", margin, y);
  y += 22;
  doc.setFont("helvetica", "normal");
  doc.setFontSize(12);
  doc.text("Automazione Ciclo Fatturazione Passiva", margin, y);
  y += 10;
  doc.setDrawColor(accent);
  doc.setLineWidth(2);
  doc.line(margin, y, pageWidth - margin, y);
  y += 18;

  // Meta
  doc.setFontSize(11);
  const metaLines = [
    `Cliente: ${user.name || "-"}`,
    `Azienda: ${user.company || "-"}`,
    `Data: ${new Date().toLocaleDateString("it-IT")}`,
  ];
  metaLines.forEach((t) => {
    doc.text(t, margin, y);
    y += 16;
  });
  y += 8;

  // Content
  doc.setFont("helvetica", "bold");
  doc.setFontSize(13);

  const addPageIfNeeded = (needed: number) => {
    if (y + needed > pageHeight - margin) {
      doc.addPage();
      y = margin;
      // Footer page number on previous page
    }
  };

  const normal = () => {
    doc.setFont("helvetica", "normal");
    doc.setFontSize(11);
    doc.setTextColor(40);
  };

  const sectionGap = 14;

  questions.forEach((q, idx) => {
    if (q.type === "info-only") return;

    const qText = `${idx + 1}. ${stripEmojis(q.text)}`;
    const qLines = doc.splitTextToSize(qText, pageWidth - margin * 2);
    addPageIfNeeded(qLines.length * 14 + 8);

    // Question title
    doc.setFont("helvetica", "bold");
    doc.setFontSize(12.5);
    doc.text(qLines, margin, y);
    y += qLines.length * 14 + 6;

    // Answer
    const ans = answers[q.id];
    if (ans) {
      normal();
      let answerText = "";
      if (typeof ans === "string") {
        answerText = ans;
      } else if (Array.isArray(ans)) {
        answerText = ans.join(", ");
      } else {
        answerText = Object.entries(ans)
          .map(([k, v]) => `${k}: ${v}`)
          .join("\n");
      }
      const ansLines = doc.splitTextToSize(`Risposta: ${answerText}`, pageWidth - margin * 2);
      addPageIfNeeded(ansLines.length * 14);
      doc.text(ansLines, margin, y);
      y += ansLines.length * 14;
    }

    // Notes
    const qNotes = notes.filter((n) => n.sectionId === q.id);
    if (qNotes.length) {
      normal();
      const notesText = qNotes.map((n) => `• ${n.content}`).join("\n");
      const noteLines = doc.splitTextToSize(`Note:\n${notesText}`, pageWidth - margin * 2);
      addPageIfNeeded(noteLines.length * 14);
      doc.text(noteLines, margin, y);
      y += noteLines.length * 14;
    }

    y += sectionGap;
  });

  // Footer with pagination
  const pageCount = doc.getNumberOfPages();
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    doc.setFontSize(10);
    doc.setTextColor(120);
    const pageLabel = `Pagina ${i} di ${pageCount}`;
    doc.text(pageLabel, pageWidth - margin - doc.getTextWidth(pageLabel), pageHeight - margin / 2);
  }

  const blob = doc.output("blob");
  const fileName = `questionario_${sanitizeFilePart(user.name || "cliente")}_${sanitizeFilePart(user.company || "azienda")}.pdf`;
  return { blob, fileName };
}

export function openPdfInNewTab(blob: Blob) {
  const url = URL.createObjectURL(blob);
  window.open(url, "_blank");
  // Revoke later
  setTimeout(() => URL.revokeObjectURL(url), 60_000);
}
