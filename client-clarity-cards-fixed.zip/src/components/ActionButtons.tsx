import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Download, MessageCircle, FileText, Send } from "lucide-react";
import { Note, Question } from "@/types/questionnaire";
import { toast } from "@/hooks/use-toast";
import { generateQuestionnairePdf, openPdfInNewTab } from "@/lib/pdf";
import { uploadPdfToStorage } from "@/lib/supabase";

interface ActionButtonsProps {
  notes: Note[];
  answers: Record<string, string | string[] | Record<string, string>>;
  questions: Question[];
  compact?: boolean;
}

const ActionButtons: React.FC<ActionButtonsProps> = ({ notes, answers, questions, compact }) => {
  const [showUserDataDialog, setShowUserDataDialog] = useState(false);
  const [userData, setUserData] = useState({ name: '', company: '' });
  const [loading, setLoading] = useState<null | 'pdf' | 'whatsapp'>(null);

  const buildPdf = async () => {
    return await generateQuestionnairePdf(questions, answers, notes, userData);
  };

  const handleDownloadPDF = async () => {
    if (!userData.name || !userData.company) {
      setShowUserDataDialog(true);
      return;
    }
    try {
      setLoading('pdf');
      const { blob } = await buildPdf();
      openPdfInNewTab(blob);
      toast({ 
        title: 'PDF Generato con Successo! 🎉', 
        description: 'Il tuo questionario si è aperto in una nuova scheda. Salvalo sul tuo dispositivo!' 
      });
    } catch (e: any) {
      toast({ 
        title: 'Errore nella Generazione PDF', 
        description: e?.message || 'Qualcosa è andato storto. Riprova tra un momento.', 
        variant: 'destructive' 
      });
    } finally {
      setLoading(null);
    }
  };

  const handleWhatsApp = async () => {
    if (!userData.name || !userData.company) {
      setShowUserDataDialog(true);
      return;
    }
    try {
      setLoading('whatsapp');
      const { blob, fileName } = await buildPdf();
      const path = `${Date.now()}_${fileName}`;
      const publicUrl = await uploadPdfToStorage(blob, path);
      
      // Messaggio WhatsApp ottimizzato secondo il tone of voice brand
      const message = `Ciao Michaela! 👋

Ho appena completato il questionario per l'automazione del ciclo fatturazione passiva.

📎 Ecco il PDF con tutte le mie risposte: ${publicUrl}

Quando hai un momento, possiamo organizzare la call per discutere la proposta specifica per il mio caso?

Grazie!
${userData.name} - ${userData.company}`;

      const whatsappUrl = `https://wa.me/393775968751?text=${encodeURIComponent(message)}`;
      window.open(whatsappUrl, '_blank');
      
      toast({ 
        title: 'WhatsApp Pronto! 🚀', 
        description: 'Ho aperto WhatsApp con il messaggio precompilato e il link al tuo PDF.' 
      });
    } catch (e: any) {
      toast({ 
        title: 'Errore Invio WhatsApp', 
        description: e?.message || 'Verifica la connessione internet e riprova.', 
        variant: 'destructive' 
      });
    } finally {
      setLoading(null);
    }
  };

  const handleUserDataSubmit = async (action: 'pdf' | 'whatsapp') => {
    if (userData.name && userData.company) {
      setShowUserDataDialog(false);
      if (action === 'pdf') {
        await handleDownloadPDF();
      } else {
        await handleWhatsApp();
      }
    }
  };

  return (
    <>
      <div className={compact ? "flex flex-col sm:flex-row gap-3 justify-center items-center" : "flex flex-col sm:flex-row gap-4 justify-center items-center p-4 margin-responsive"}>
        
        {/* PDF DOWNLOAD BUTTON */}
        <Button
          onClick={handleDownloadPDF}
          disabled={!!loading}
          className="btn-primary px-6 py-3 rounded-lg font-bold hover-scale transition-brand focus-brand w-full sm:w-auto min-w-[200px]"
          aria-label="Scarica il questionario completato in formato PDF"
        >
          {loading === 'pdf' ? (
            <>
              <div className="w-5 h-5 mr-2 animate-spin rounded-full border-2 border-transparent border-t-current" />
              <span>Generazione...</span>
            </>
          ) : (
            <>
              <Download className="w-5 h-5 mr-2" />
              <span>📄 Scarica PDF</span>
            </>
          )}
        </Button>
        
        {/* WHATSAPP SEND BUTTON */}
        <Button
          onClick={handleWhatsApp}
          disabled={!!loading}
          className="btn-whatsapp px-6 py-3 rounded-lg font-bold hover-scale transition-brand focus-brand w-full sm:w-auto min-w-[200px]"
          aria-label="Invia il questionario direttamente a Michaela via WhatsApp"
        >
          {loading === 'whatsapp' ? (
            <>
              <div className="w-5 h-5 mr-2 animate-spin rounded-full border-2 border-transparent border-t-current" />
              <span>Preparazione...</span>
            </>
          ) : (
            <>
              <MessageCircle className="w-5 h-5 mr-2" />
              <span>💬 Invia a Michaela</span>
            </>
          )}
        </Button>
      </div>

      {/* USER DATA COLLECTION DIALOG */}
      <Dialog open={showUserDataDialog} onOpenChange={setShowUserDataDialog}>
        <DialogContent className="max-w-md card-shadow">
          <DialogHeader className="text-center pb-4">
            <DialogTitle className="text-xl font-bold text-primary uppercase tracking-wide">
              📋 Informazioni Contatto
            </DialogTitle>
            <p className="text-sm text-muted-foreground mt-2">
              Solo due info veloci per personalizzare il tuo PDF
            </p>
          </DialogHeader>
          
          <div className="space-y-4">
            <div>
              <label className="text-sm font-semibold text-primary uppercase tracking-wide block mb-2">
                Nome Completo *
              </label>
              <Input
                placeholder="Es: Mario Rossi"
                value={userData.name}
                onChange={(e) => setUserData(prev => ({ ...prev, name: e.target.value }))}
                className="focus:border-secondary transition-brand"
                required
              />
            </div>
            
            <div>
              <label className="text-sm font-semibold text-primary uppercase tracking-wide block mb-2">
                Nome Azienda *
              </label>
              <Input
                placeholder="Es: Rossi Costruzioni S.r.l."
                value={userData.company}
                onChange={(e) => setUserData(prev => ({ ...prev, company: e.target.value }))}
                className="focus:border-secondary transition-brand"
                required
              />
            </div>
            
            {/* ACTION BUTTONS */}
            <div className="flex flex-col gap-3 pt-4 border-t border-secondary/20">
              <Button
                onClick={() => handleUserDataSubmit('pdf')}
                disabled={!userData.name || !userData.company || !!loading}
                className="btn-primary w-full hover-scale transition-brand focus-brand"
                aria-label="Conferma dati e scarica PDF"
              >
                {loading === 'pdf' ? (
                  <>
                    <div className="w-4 h-4 mr-2 animate-spin rounded-full border-2 border-transparent border-t-current" />
                    <span>Generazione PDF...</span>
                  </>
                ) : (
                  <>
                    <FileText className="w-4 h-4 mr-2" />
                    <span>📄 Genera e Scarica PDF</span>
                  </>
                )}
              </Button>
              
              <Button
                onClick={() => handleUserDataSubmit('whatsapp')}
                disabled={!userData.name || !userData.company || !!loading}
                className="btn-whatsapp w-full hover-scale transition-brand focus-brand"
                aria-label="Conferma dati e invia via WhatsApp"
              >
                {loading === 'whatsapp' ? (
                  <>
                    <div className="w-4 h-4 mr-2 animate-spin rounded-full border-2 border-transparent border-t-current" />
                    <span>Preparazione...</span>
                  </>
                ) : (
                  <>
                    <Send className="w-4 h-4 mr-2" />
                    <span>💬 Invia via WhatsApp</span>
                  </>
                )}
              </Button>
            </div>
            
            {/* PRIVACY NOTICE */}
            <div className="text-center pt-2">
              <p className="text-xs text-muted-foreground leading-relaxed">
                🔒 I tuoi dati sono sicuri e vengono utilizzati solo per personalizzare il PDF. 
                Non vendiamo né condividiamo informazioni con terze parti.
              </p>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default ActionButtons;