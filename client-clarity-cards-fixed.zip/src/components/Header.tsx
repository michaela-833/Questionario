import React from "react";
import { Menu } from "lucide-react";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";

const Header: React.FC = () => {
  // Link WhatsApp ufficiale con messaggio brand-specific
  const whatsappUrl = "https://wa.me/393775968751?text=Ciao%20Michaela!%20Sono%20interessato%20alle%20tue%20soluzioni%20di%20automazione.%20Possiamo%20parlarne%3F";

  return (
    <header className="sticky top-0 z-50 w-full bg-background text-foreground backdrop-blur-md supports-[backdrop-filter]:bg-background/95 border-b border-border/20">
      <div className="container mx-auto flex items-center justify-between py-4 px-4">
        {/* LOGO SECTION - Logo più grande, sfondo uguale al body */}
        <a 
          href="/" 
          className="flex items-center gap-3 group transition-brand hover-scale focus-brand" 
          aria-label="Micha Marketing"
        >
          {/* Logo per sfondo chiaro (stesso del body) */}
          <img
            src="https://i.imgur.com/aFjRVXi.png"
            alt="Micha Marketing logo"
            className="h-16 w-auto sm:h-18 lg:h-20 transition-all duration-300 group-hover:scale-105"
            loading="eager"
            width={200}
            height={60}
          />
          
          {/* Logo aziendale testo per screen readers */}
          <div className="sr-only">
            <span className="font-bold">Micha Marketing</span>
            <span className="block text-sm">Automazioni fatte per esseri umani</span>
          </div>
        </a>

        {/* DESKTOP NAVIGATION */}
        <nav 
          aria-label="Navigazione principale" 
          className="hidden md:flex items-center gap-6 text-sm font-medium"
        >
          <a 
            href="#questionario" 
            className="text-foreground/90 hover:text-foreground transition-brand hover-scale focus-brand uppercase tracking-wide font-semibold"
          >
            Questionario
          </a>
          <a
            href={whatsappUrl}
            className="btn-whatsapp px-4 py-2 rounded-full text-sm font-bold inline-flex items-center gap-2 hover-scale focus-brand"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Contatta Michaela via WhatsApp"
          >
            <span>💬</span>
            <span>Contatta Michaela</span>
          </a>
        </nav>

        {/* MOBILE MENU TRIGGER */}
        <div className="md:hidden">
          <Sheet>
            <SheetTrigger 
              aria-label="Apri menu di navigazione" 
              className="p-2 rounded-md hover:bg-foreground/10 transition-brand focus-brand"
            >
              <Menu className="h-6 w-6 text-foreground" />
            </SheetTrigger>
            
            <SheetContent 
              side="right" 
              className="w-80 bg-background border-l border-border/20"
            >
              <SheetHeader className="text-left pb-6 border-b border-border/20">
                <SheetTitle className="text-foreground font-bold text-lg uppercase tracking-wide">
                  Micha Marketing
                </SheetTitle>
                <p className="text-foreground/80 text-sm">
                  Questionario Preventivo
                </p>
              </SheetHeader>
              
              {/* MOBILE NAVIGATION LINKS */}
              <div className="mt-6 grid gap-4">
                <a 
                  href="#questionario" 
                  className="flex items-center px-4 py-3 text-foreground hover:bg-foreground/10 rounded-lg transition-brand focus-brand uppercase tracking-wide font-semibold"
                  onClick={() => (document.activeElement as HTMLElement)?.blur?.()}
                >
                  <span className="mr-3">📋</span>
                  Questionario
                </a>
                
                <div className="border-t border-border/20 pt-4 mt-4">
                  <a
                    href={whatsappUrl}
                    className="btn-whatsapp w-full px-4 py-3 rounded-lg text-sm font-bold flex items-center justify-center gap-2 hover-scale focus-brand"
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label="Contatta Michaela via WhatsApp"
                  >
                    <span>💬</span>
                    <span>Contatta Michaela</span>
                  </a>
                  
                  {/* CONTACT INFO SECTION */}
                  <div className="mt-4 p-4 bg-foreground/5 rounded-lg">
                    <h3 className="text-foreground font-semibold text-sm uppercase tracking-wide mb-2">
                      Contatti Diretti
                    </h3>
                    <div className="space-y-2 text-sm">
                      <a 
                        href="tel:+393775968751" 
                        className="block text-foreground/80 hover:text-foreground transition-brand"
                      >
                        📞 +39 377.596.87.51
                      </a>
                      <a 
                        href="mailto:michaela@michamarketing.com" 
                        className="block text-foreground/80 hover:text-foreground transition-brand"
                      >
                        ✉️ michaela@michamarketing.com
                      </a>
                      <a 
                        href="https://www.michamarketing.com" 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="block text-foreground/80 hover:text-foreground transition-brand"
                      >
                        🌐 www.michamarketing.com
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
};

export default Header;