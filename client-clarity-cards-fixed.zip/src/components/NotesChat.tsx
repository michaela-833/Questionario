import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Note } from "@/types/questionnaire";
import { MessageSquare, Edit, Trash2, Save, X, StickyNote, Clock } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface NotesChatProps {
  notes: Note[];
  onUpdateNote: (noteId: string, content: string) => void;
  onDeleteNote: (noteId: string) => void;
}

const NotesChat: React.FC<NotesChatProps> = ({ notes, onUpdateNote, onDeleteNote }) => {
  const [editingNoteId, setEditingNoteId] = useState<string | null>(null);
  const [editContent, setEditContent] = useState('');
  const { toast } = useToast();

  const startEditing = (note: Note) => {
    setEditingNoteId(note.id);
    setEditContent(note.content);
  };

  const cancelEditing = () => {
    setEditingNoteId(null);
    setEditContent('');
  };

  const saveEdit = () => {
    if (editingNoteId && editContent.trim()) {
      onUpdateNote(editingNoteId, editContent.trim());
      setEditingNoteId(null);
      setEditContent('');
      toast({
        title: "Nota Aggiornata ✅",
        description: "La tua nota è stata modificata con successo.",
      });
    }
  };

  const deleteNote = (noteId: string) => {
    onDeleteNote(noteId);
    toast({
      title: "Nota Eliminata 🗑️",
      description: "La nota è stata rimossa dal questionario.",
    });
  };

  // Group notes by section for better organization
  const groupedNotes = notes.reduce((acc, note) => {
    const sectionId = note.sectionId;
    if (!acc[sectionId]) {
      acc[sectionId] = [];
    }
    acc[sectionId].push(note);
    return acc;
  }, {} as Record<string, Note[]>);

  // Helper function to get section name from question ID
  const getSectionName = (questionId: string): string => {
    const sectionMap: Record<string, string> = {
      'intro-': '🎨 Introduzione',
      'vol-': '📊 Volumi e Impatto',
      'sys-': '💻 Sistema e Accessi',
      'fmt-': '📄 Formati e Digital',
      'gro-': '📈 Crescita e Performance', 
      'org-': '👥 Organizzazione',
      'asp-': '🎯 Aspettative e Visione',
      'auth-': '🤝 Autorizzazioni',
      'conc-': '📝 Conclusioni'
    };
    
    for (const [prefix, name] of Object.entries(sectionMap)) {
      if (questionId.startsWith(prefix)) {
        return name;
      }
    }
    
    return '📋 Questionario';
  };

  if (notes.length === 0) {
    return (
      <Card className="w-full max-w-4xl mx-auto card-shadow">
        <CardHeader className="bg-micha-gray-light/30 border-b border-secondary/20">
          <CardTitle className="flex items-center gap-3 text-primary uppercase tracking-wide">
            <div className="p-2 bg-secondary/10 rounded-full">
              <StickyNote className="w-5 h-5 text-secondary" />
            </div>
            <span>Riepilogo Note</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="p-8">
          <div className="text-center py-8">
            <div className="w-20 h-20 mx-auto mb-4 bg-micha-gray-light rounded-full flex items-center justify-center">
              <MessageSquare className="w-8 h-8 text-muted-foreground opacity-50" />
            </div>
            <h3 className="text-lg font-semibold text-primary mb-2 uppercase tracking-wide">
              Nessuna Nota Presente
            </h3>
            <p className="text-muted-foreground leading-relaxed max-w-md mx-auto">
              Le note che aggiungerai durante la compilazione del questionario appariranno qui. 
              Potrai modificarle, eliminarle e rivederle prima di generare il PDF finale.
            </p>
            <div className="mt-6 inline-flex items-center gap-2 text-sm text-muted-foreground">
              <StickyNote className="w-4 h-4" />
              <span>Usa il pulsante "📝 Aggiungi nota" per iniziare</span>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full max-w-4xl mx-auto card-shadow">
      <CardHeader className="bg-micha-gray-light/30 border-b border-secondary/20">
        <CardTitle className="flex items-center gap-3 text-primary uppercase tracking-wide">
          <div className="p-2 bg-secondary/10 rounded-full">
            <StickyNote className="w-5 h-5 text-secondary" />
          </div>
          <span>Riepilogo Note</span>
          <div className="bg-secondary text-secondary-foreground px-3 py-1 rounded-full text-sm font-bold">
            {notes.length}
          </div>
        </CardTitle>
      </CardHeader>
      
      <CardContent className="p-6 space-y-6 max-h-[60vh] overflow-y-auto">
        {Object.entries(groupedNotes).map(([sectionId, sectionNotes]) => (
          <div key={sectionId} className="space-y-3">
            
            {/* SECTION HEADER */}
            <div className="flex items-center gap-2 pb-2 border-b border-secondary/20">
              <div className="w-2 h-2 bg-secondary rounded-full" />
              <h4 className="font-semibold text-primary text-sm uppercase tracking-wide">
                {getSectionName(sectionId)}
              </h4>
              <div className="text-xs text-muted-foreground bg-micha-gray-light px-2 py-1 rounded">
                {sectionNotes.length} {sectionNotes.length === 1 ? 'nota' : 'note'}
              </div>
            </div>

            {/* NOTES IN SECTION */}
            {sectionNotes.map((note) => (
              <div 
                key={note.id} 
                className="bg-card border border-secondary/20 rounded-lg p-4 hover:shadow-md transition-all duration-300 hover-scale"
              >
                <div className="flex justify-between items-start mb-3">
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <Clock className="w-3 h-3" />
                    <span>
                      {new Date(note.timestamp).toLocaleString('it-IT', {
                        day: '2-digit',
                        month: '2-digit',
                        year: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit'
                      })}
                    </span>
                  </div>
                  
                  {editingNoteId !== note.id && (
                    <div className="flex gap-1">
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => startEditing(note)}
                        className="h-7 px-2 text-xs hover-scale transition-brand focus-brand"
                      >
                        <Edit className="w-3 h-3 mr-1" />
                        <span className="hidden sm:inline">Modifica</span>
                      </Button>
                      <Button 
                        size="sm" 
                        variant="destructive"
                        onClick={() => deleteNote(note.id)}
                        className="h-7 px-2 text-xs hover-scale transition-brand focus-brand"
                      >
                        <Trash2 className="w-3 h-3 mr-1" />
                        <span className="hidden sm:inline">Elimina</span>
                      </Button>
                    </div>
                  )}
                </div>
                
                {/* NOTE CONTENT */}
                {editingNoteId === note.id ? (
                  <div className="space-y-3">
                    <Textarea
                      value={editContent}
                      onChange={(e) => setEditContent(e.target.value)}
                      className="min-h-[80px] focus:border-secondary transition-brand"
                      placeholder="Modifica il contenuto della nota..."
                    />
                    <div className="flex gap-2">
                      <Button 
                        size="sm" 
                        onClick={saveEdit}
                        className="btn-primary hover-scale transition-brand focus-brand"
                        disabled={!editContent.trim()}
                      >
                        <Save className="w-4 h-4 mr-1" />
                        <span>Salva Modifiche</span>
                      </Button>
                      <Button 
                        size="sm" 
                        variant="outline" 
                        onClick={cancelEditing}
                        className="hover-scale transition-brand focus-brand"
                      >
                        <X className="w-4 h-4 mr-1" />
                        <span>Annulla</span>
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="bg-micha-gray-light/50 p-3 rounded border-l-4 border-secondary">
                    <p className="text-sm leading-relaxed whitespace-pre-wrap">
                      {note.content}
                    </p>
                  </div>
                )}
              </div>
            ))}
          </div>
        ))}

        {/* SUMMARY FOOTER */}
        <div className="border-t border-secondary/20 pt-4 mt-6">
          <div className="bg-micha-gray-light/30 p-4 rounded-lg">
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-2 text-muted-foreground">
                <div className="w-2 h-2 bg-accent rounded-full animate-pulse" />
                <span className="font-medium">
                  Tutte le note saranno incluse nel PDF finale organizzate per sezione
                </span>
              </div>
              <div className="text-xs text-muted-foreground">
                {notes.length} {notes.length === 1 ? 'nota totale' : 'note totali'}
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default NotesChat;