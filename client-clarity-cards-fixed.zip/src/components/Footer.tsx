import React from 'react';
import { Mail, Phone, Linkedin, Instagram, Globe, Youtube, Facebook } from "lucide-react";

const Footer: React.FC = () => {
  return (
    <div className="relative overflow-hidden">
      {/* DECORATIVE TOP BAND - Esattamente 15° come da linee guida */}
      <div 
        aria-hidden="true" 
        className="pointer-events-none absolute -top-8 left-0 hidden w-full sm:block"
      >
        <div className="mx-auto h-6 w-3/4 bg-micha-blue-medium opacity-20 diagonal-band" />
        <div className="mx-auto h-4 w-2/3 bg-accent opacity-30 diagonal-band translate-y-2" />
      </div>

      <footer className="relative bg-footer text-footer-foreground py-8">
        <div className="container mx-auto px-4">
          <div className="grid gap-6 lg:grid-cols-2 items-start">
            
            {/* LOGO E BRAND SECTION */}
            <div className="space-y-4">
              <div className="flex items-center gap-4">
                <img
                  src="https://i.imgur.com/ZPgzJch.png"
                  alt="Logo Micha Marketing per sfondo scuro"
                  className="h-10 w-auto lg:h-12 hover-scale transition-brand"
                  loading="lazy"
                  width={160}
                  height={48}
                />
                <div>
                  <h3 className="text-xl lg:text-2xl font-bold tracking-wide text-footer-foreground">
                    Micha Marketing
                  </h3>
                  {/* ICONE SOCIAL SOTTO IL NOME */}
                  <div className="flex items-center gap-3 mt-2">
                    <a
                      href="https://www.youtube.com/@michaela833"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="social-icon social-youtube hover-scale focus-brand"
                      aria-label="Canale YouTube di Michaela"
                    >
                      <Youtube className="w-4 h-4" />
                    </a>
                    
                    <a
                      href="https://linkedin.com/in/michaela-beccari"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="social-icon social-linkedin hover-scale focus-brand"
                      aria-label="Profilo LinkedIn di Michaela Beccari"
                    >
                      <Linkedin className="w-4 h-4" />
                    </a>
                    
                    <a
                      href="https://www.facebook.com/people/Micha-Marketing/106666154407984/"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="social-icon social-facebook hover-scale focus-brand"
                      aria-label="Pagina Facebook di Micha Marketing"
                    >
                      <Facebook className="w-4 h-4" />
                    </a>
                    
                    <a
                      href="https://instagram.com/micha.marketing"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="social-icon social-instagram hover-scale focus-brand"
                      aria-label="Profilo Instagram di Micha Marketing"
                    >
                      <Instagram className="w-4 h-4" />
                    </a>
                  </div>
                </div>
              </div>
            </div>

            {/* CONTATTI SECTION */}
            <div className="space-y-3 lg:justify-self-end lg:text-right">
              <h4 className="font-bold text-lg text-footer-foreground uppercase tracking-wide mb-3">
                Contatti Diretti
              </h4>
              
              <div className="space-y-2">
                <a 
                  href="tel:+393775968751" 
                  className="flex items-center gap-3 lg:justify-end text-footer-foreground/90 hover:text-footer-foreground transition-brand hover-scale group focus-brand"
                  aria-label="Chiama Michaela al +39 377 596 87 51"
                >
                  <Phone className="w-4 h-4 group-hover:scale-110 transition-transform" />
                  <span className="font-medium">+39 377.596.87.51</span>
                </a>
                
                <a 
                  href="mailto:michaela@michamarketing.com" 
                  className="flex items-center gap-3 lg:justify-end text-footer-foreground/90 hover:text-footer-foreground transition-brand hover-scale group focus-brand"
                  aria-label="Invia email a michaela@michamarketing.com"
                >
                  <Mail className="w-4 h-4 group-hover:scale-110 transition-transform" />
                  <span className="font-medium">michaela@michamarketing.com</span>
                </a>
                
                <a 
                  href="https://www.michamarketing.com" 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="flex items-center gap-3 lg:justify-end text-footer-foreground/90 hover:text-footer-foreground transition-brand hover-scale group focus-brand"
                  aria-label="Visita il sito web michamarketing.com"
                >
                  <Globe className="w-4 h-4 group-hover:scale-110 transition-transform" />
                  <span className="font-medium">www.michamarketing.com</span>
                </a>
              </div>
            </div>
          </div>

          {/* COPYRIGHT E PRIVACY */}
          <div className="mt-6 pt-6 border-t border-footer-foreground/20">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-sm text-footer-foreground/60">
              <div>
                <p>© 2024 Micha Marketing</p>
              </div>
              
              <div className="flex flex-col sm:flex-row items-center gap-4">
                <a 
                  href="/privacy" 
                  className="hover:text-footer-foreground/80 transition-brand focus-brand uppercase tracking-wide"
                >
                  Privacy Policy
                </a>
                <span className="hidden sm:inline">•</span>
                <a 
                  href="/terms" 
                  className="hover:text-footer-foreground/80 transition-brand focus-brand uppercase tracking-wide"
                >
                  Termini di Servizio
                </a>
                <span className="hidden sm:inline">•</span>
                <a 
                  href="/cookies" 
                  className="hover:text-footer-foreground/80 transition-brand focus-brand uppercase tracking-wide"
                >
                  Cookie Policy
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* DECORATIVE BOTTOM ELEMENTS */}
        <div 
          aria-hidden="true" 
          className="pointer-events-none absolute -bottom-4 right-0 w-1/3 h-8 bg-secondary opacity-10 diagonal-band-negative"
        />
      </footer>
    </div>
  );
};

export default Footer;