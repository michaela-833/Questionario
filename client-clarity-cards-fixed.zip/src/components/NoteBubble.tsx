import React, { useMemo, useState } from "react";
import { MessageCircle, StickyNote } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import NotesChat from "@/components/NotesChat";
import { Note } from "@/types/questionnaire";

interface NoteBubbleProps {
  notes: Note[];
  onUpdateNote: (noteId: string, content: string) => void;
  onDeleteNote: (noteId: string) => void;
}

const NoteBubble: React.FC<NoteBubbleProps> = ({ notes, onUpdateNote, onDeleteNote }) => {
  const [open, setOpen] = useState(false);

  const summary = useMemo(() => {
    const count = notes.length;
    const last = notes[count - 1]?.content || "";
    const preview = last.length > 50 ? last.slice(0, 47) + "…" : last;
    return { count, preview };
  }, [notes]);

  // Se non ci sono note, mostra un bubble più discreto
  const hasNotes = notes.length > 0;

  return (
    <>
      {/* FLOATING NOTE BUBBLE - Chat style migliorato */}
      <div className="fixed bottom-6 right-6 z-50">
        <button
          aria-label={`Riepilogo note: ${summary.count} note salvate`}
          onClick={() => setOpen(true)}
          className={`note-bubble hover-scale transition-brand focus-brand group ${
            hasNotes ? 'animate-pulse' : ''
          }`}
        >
          <div className="flex items-center gap-3">
            {/* ICON CONTAINER */}
            <span className={`inline-flex h-10 w-10 items-center justify-center rounded-full shadow-lg transition-all duration-300 ${
              hasNotes ? 'bg-secondary text-secondary-foreground' : 'bg-micha-gray-light text-primary'
            } group-hover:scale-110`}>
              {hasNotes ? (
                <StickyNote className="h-5 w-5" />
              ) : (
                <MessageCircle className="h-5 w-5" />
              )}
            </span>
            
            {/* TEXT CONTENT */}
            <div className="text-left leading-tight max-w-[180px]">
              <div className={`text-sm font-bold uppercase tracking-wide ${
                hasNotes ? 'text-primary' : 'text-muted-foreground'
              }`}>
                📝 Note ({summary.count})
              </div>
              <div className="text-xs text-muted-foreground truncate">
                {hasNotes ? (
                  summary.preview
                ) : (
                  "Aggiungi note durante il questionario"
                )}
              </div>
            </div>
          </div>

          {/* NOTIFICATION DOT per nuove note */}
          {hasNotes && (
            <div className="absolute -top-1 -right-1 w-3 h-3 bg-accent rounded-full animate-pulse border-2 border-background" />
          )}
        </button>
      </div>

      {/* NOTES DIALOG */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-3xl max-h-[80vh] card-shadow">
          <DialogHeader className="border-b border-secondary/20 pb-4">
            <DialogTitle className="flex items-center gap-3 text-xl font-bold text-primary uppercase tracking-wide">
              <div className="p-2 bg-secondary/10 rounded-full">
                <StickyNote className="w-6 h-6 text-secondary" />
              </div>
              <span>Riepilogo Note</span>
              {hasNotes && (
                <span className="bg-secondary text-secondary-foreground px-2 py-1 rounded-full text-sm font-bold">
                  {summary.count}
                </span>
              )}
            </DialogTitle>
          </DialogHeader>
          
          {/* NOTES CONTENT */}
          <div className="overflow-y-auto max-h-[60vh]">
            <NotesChat
              notes={notes}
              onUpdateNote={onUpdateNote}
              onDeleteNote={onDeleteNote}
            />
          </div>

          {/* FOOTER INFO */}
          {hasNotes && (
            <div className="border-t border-secondary/20 pt-4 mt-4">
              <div className="flex items-center justify-between text-sm text-muted-foreground">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-secondary rounded-full" />
                  <span>Le tue note saranno incluse nel PDF finale</span>
                </div>
                <div className="text-xs">
                  Ultima modifica: {new Date(Math.max(...notes.map(n => n.timestamp))).toLocaleString('it-IT', {
                    day: '2-digit',
                    month: '2-digit',
                    hour: '2-digit',
                    minute: '2-digit'
                  })}
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
};

export default NoteBubble;