import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { ChevronLeft, ChevronRight, StickyNote } from "lucide-react";
import { Question, Note } from "@/types/questionnaire";

interface FlashCardProps {
  question: Question;
  currentIndex: number;
  totalQuestions: number;
  onNext: () => void;
  onPrevious: () => void;
  notes: Note[];
  onAddNote: (questionId: string, content: string) => void;
  onAnswerChange: (questionId: string, answer: string | string[] | Record<string, string>) => void;
  showNotes?: boolean;
  conditionalDependencies?: Record<string, string | string[]>;
  finalActions?: React.ReactNode;
}

const FlashCard: React.FC<FlashCardProps> = ({
  question,
  currentIndex,
  totalQuestions,
  onNext,
  onPrevious,
  notes,
  onAddNote,
  onAnswerChange,
  showNotes = true,
  conditionalDependencies = {},
  finalActions,
}) => {
  const [noteContent, setNoteContent] = useState('');
  const [showNoteInput, setShowNoteInput] = useState(false);

  const questionNotes = notes.filter(note => note.sectionId === question.id);

  const handleAddNote = () => {
    if (noteContent.trim()) {
      onAddNote(question.id, noteContent.trim());
      setNoteContent('');
      setShowNoteInput(false);
    }
  };

  const handleMultipleChoiceSelect = (option: string) => {
    onAnswerChange(question.id, option);
  };

  const handleCheckboxChange = (option: string, checked: boolean) => {
    const currentAnswers = Array.isArray(question.answer) ? question.answer : [];
    let newAnswers;
    
    if (checked) {
      newAnswers = [...currentAnswers, option];
    } else {
      newAnswers = currentAnswers.filter(a => a !== option);
    }
    
    onAnswerChange(question.id, newAnswers);
  };

  const handleTextChange = (value: string) => {
    onAnswerChange(question.id, value);
  };

  const handleTextMultipleChange = (field: string, value: string) => {
    const currentAnswer = question.answer as Record<string, string> || {};
    onAnswerChange(question.id, { ...currentAnswer, [field]: value });
  };

  const isFieldRequired = (field?: { required?: boolean }) => {
    if (question.conditionalRequired && question.conditionalRequired.dependsOn) {
      const dependentValue = conditionalDependencies[question.conditionalRequired.dependsOn];
      const shouldBeRequired = Array.isArray(dependentValue) 
        ? dependentValue.includes(question.conditionalRequired.value)
        : dependentValue === question.conditionalRequired.value;
      return shouldBeRequired;
    }
    return field?.required !== false && question.required !== false;
  };

  // Check if question should be displayed conditionally
  const shouldDisplayQuestion = () => {
    if (question.conditionalDisplay && question.conditionalDisplay.dependsOn) {
      const dependentValue = conditionalDependencies[question.conditionalDisplay.dependsOn];
      return Array.isArray(dependentValue) 
        ? dependentValue.includes(question.conditionalDisplay.value)
        : dependentValue === question.conditionalDisplay.value;
    }
    return true;
  };

  // Check if question is answered (for mandatory progression)
  const isQuestionAnswered = () => {
    if (question.type === 'info-only') return true;
    if (question.required === false) return true;
    
    const answer = question.answer;
    if (!answer) return false;
    
    if (typeof answer === 'string') return answer.trim().length > 0;
    if (Array.isArray(answer)) return answer.length > 0;
    if (typeof answer === 'object') return Object.values(answer).some(v => v.trim().length > 0);
    
    return false;
  };

  const isFirstQuestion = currentIndex === 0;
  const isLastQuestion = currentIndex === totalQuestions - 1;

  // Don't render if conditional display requirements not met
  if (!shouldDisplayQuestion()) {
    return null;
  }

  return (
    <Card className="w-full max-w-4xl mx-auto min-h-[70vh] flex flex-col card-shadow margin-responsive hover-scale transition-brand">
      
      {/* CARD HEADER - Brand styling */}
      <CardHeader className="bg-primary text-primary-foreground relative overflow-hidden py-4 sm:py-6">
        {/* Background pattern */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 right-0 w-1/3 h-full bg-secondary diagonal-band" />
          <div className="absolute top-0 right-8 w-1/4 h-full bg-accent diagonal-band" />
        </div>
        
        <div className="relative flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
          <CardTitle className="text-lg sm:text-xl font-bold">
            {isFirstQuestion ? "🎨 Introduzione" : `📋 Domanda ${currentIndex}`}
          </CardTitle>
          <span className="text-xs sm:text-sm bg-primary-foreground/20 px-3 py-1 rounded-full font-semibold">
            {currentIndex + 1} di {totalQuestions}
          </span>
        </div>
      </CardHeader>

      {/* CARD CONTENT */}
      <CardContent className="flex-1 padding-responsive flex flex-col justify-center space-y-6">
        <div className="space-y-6">
          
          {/* QUESTION TEXT */}
          <div className="text-center">
            <div 
              className="text-responsive font-medium text-foreground leading-relaxed whitespace-pre-line"
              dangerouslySetInnerHTML={{
                __html: question.text
                  .replace(/\*([^*]+)\*/g, '<em>$1</em>') // Convert *text* to <em>text</em>
                  .replace(/\n/g, '<br>') // Convert line breaks
              }}
            />
          </div>

          {/* MULTIPLE CHOICE */}
          {question.type === 'multiple-choice' && question.options && (
            <div className="grid gap-3 w-full max-w-2xl mx-auto">
              {question.options.map((option, index) => {
                const isOtherOption = option.includes("Altro") || option.includes("altro") || option.includes(": ____");
                const isSelected = question.answer === option || 
                  (isOtherOption && typeof question.answer === 'string' && question.answer.startsWith(option.split(':')[0]));
                
                return (
                  <div key={index} className="w-full">
                    <Button
                      variant={isSelected ? "default" : "outline"}
                      className={`w-full text-left justify-start h-auto p-4 whitespace-normal transition-brand hover-scale ${
                        isSelected ? 'btn-primary shadow-lg' : 'hover:shadow-md hover:border-secondary/50'
                      }`}
                      onClick={() => {
                        // Allow deselection by clicking again
                        if (isSelected) {
                          onAnswerChange(question.id, '');
                        } else {
                          handleMultipleChoiceSelect(option);
                        }
                      }}
                    >
                      {option}
                    </Button>
                    
                    {isOtherOption && isSelected && (
                      <Input
                        placeholder="Specifica altro..."
                        className="mt-2 w-full focus:border-secondary transition-brand"
                        onClick={(e) => e.stopPropagation()}
                        defaultValue={
                          typeof question.answer === 'string' && question.answer.includes(':') 
                            ? question.answer.split(':')[1]?.trim() || ''
                            : ''
                        }
                        onChange={(e) => {
                          const customValue = `${option.split(':')[0]}: ${e.target.value}`;
                          onAnswerChange(question.id, customValue);
                        }}
                      />
                    )}
                  </div>
                );
              })}
            </div>
          )}

          {/* CHECKBOX */}
          {question.type === 'checkbox' && question.options && (
            <div className="grid gap-3 w-full max-w-2xl mx-auto">
              {question.options.map((option, index) => {
                const isOtherOption = option.includes("Altro") || option.includes("altro") || option.includes(": ____");
                const isChecked = Array.isArray(question.answer) && question.answer.some(a => 
                  a === option || (isOtherOption && a.startsWith(option.split(':')[0]))
                );
                
                return (
                  <div key={index} className="w-full">
                    <div className="flex items-center space-x-3 p-4 rounded-lg border hover:shadow-md hover:border-secondary/50 transition-brand">
                      <Checkbox
                        checked={isChecked}
                        onCheckedChange={(checked) => handleCheckboxChange(option, checked as boolean)}
                        className="border-secondary data-[state=checked]:bg-secondary"
                      />
                      <label className="flex-1 text-sm font-medium leading-relaxed cursor-pointer"
                        onClick={() => handleCheckboxChange(option, !isChecked)}
                      >
                        {option}
                      </label>
                    </div>
                    
                    {isOtherOption && isChecked && (
                      <Input
                        placeholder="Specifica altro..."
                        className="mt-2 w-full focus:border-secondary transition-brand"
                        defaultValue={
                          Array.isArray(question.answer) 
                            ? question.answer.find(a => a.startsWith(option.split(':')[0]))?.split(':')[1]?.trim() || ''
                            : ''
                        }
                        onChange={(e) => {
                          const currentAnswers = Array.isArray(question.answer) ? question.answer : [];
                          const filteredAnswers = currentAnswers.filter(a => !a.startsWith(option.split(':')[0]));
                          const customValue = `${option.split(':')[0]}: ${e.target.value}`;
                          onAnswerChange(question.id, [...filteredAnswers, customValue]);
                        }}
                      />
                    )}
                  </div>
                );
              })}
            </div>
          )}

          {/* TEXT INPUT */}
          {question.type === 'text' && (
            <div className="w-full max-w-2xl mx-auto">
              <Input
                placeholder="Scrivi la tua risposta..."
                value={typeof question.answer === 'string' ? question.answer : ''}
                onChange={(e) => handleTextChange(e.target.value)}
                className="w-full text-center focus:border-secondary transition-brand"
                required={isFieldRequired()}
              />
            </div>
          )}

          {/* TEXTAREA */}
          {question.type === 'textarea' && (
            <div className="w-full max-w-2xl mx-auto">
              <Textarea
                placeholder="Scrivi la tua risposta..."
                value={typeof question.answer === 'string' ? question.answer : ''}
                onChange={(e) => handleTextChange(e.target.value)}
                className="min-h-[120px] w-full focus:border-secondary transition-brand"
                required={isFieldRequired()}
              />
            </div>
          )}

          {/* TEXT MULTIPLE */}
          {question.type === 'text-multiple' && question.fields && (
            <div className="w-full max-w-2xl mx-auto space-y-4">
              {question.fields.map((field, index) => (
                <div key={index} className="space-y-2">
                  <label className="text-sm font-medium text-muted-foreground uppercase tracking-wide">
                    {field.label} {isFieldRequired(field) && <span className="text-destructive">*</span>}
                  </label>
                  <Input
                    placeholder={field.placeholder}
                    value={((question.answer as Record<string, string>) || {})[field.label] || ''}
                    onChange={(e) => handleTextMultipleChange(field.label, e.target.value)}
                    className="w-full focus:border-secondary transition-brand"
                    required={isFieldRequired(field)}
                  />
                </div>
              ))}
            </div>
          )}

          {/* INFO ONLY - Final page */}
          {question.type === 'info-only' && (
            <div className="text-center bg-gradient-to-r from-micha-gray-light/20 to-accent/10 p-8 rounded-lg border border-secondary/20">
              <div className="text-4xl mb-4">🎉</div>
              <h2 className="text-xl font-bold mb-4 text-primary uppercase tracking-wide">
                Complimenti! Hai completato il questionario
              </h2>
              <p className="text-muted-foreground mb-6 leading-relaxed">
                Ora puoi scaricare il PDF con tutte le tue risposte o inviarlo direttamente a Michaela via WhatsApp.
              </p>
              {finalActions && (
                <div className="mt-6">
                  {finalActions}
                </div>
              )}
            </div>
          )}
        </div>

        {/* NOTES SECTION */}
        {showNotes && !isFirstQuestion && question.type !== 'info-only' && (
          <div className="border-t border-secondary/20 pt-6">
            <div className="flex items-center justify-between mb-4">
              <h4 className="font-medium flex items-center gap-2 text-sm">
                <StickyNote className="w-4 h-4 text-secondary" />
                <span>Note per questa domanda</span>
              </h4>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowNoteInput(!showNoteInput)}
                className="btn-accent text-xs font-bold hover-scale transition-brand focus-brand"
              >
                📝 Aggiungi nota
              </Button>
            </div>

            {showNoteInput && (
              <div className="space-y-3 mb-4">
                <Textarea
                  placeholder="Scrivi le tue note per questa domanda..."
                  value={noteContent}
                  onChange={(e) => setNoteContent(e.target.value)}
                  className="min-h-[100px] focus:border-secondary transition-brand"
                />
                <div className="flex gap-2">
                  <Button 
                    onClick={handleAddNote} 
                    size="sm" 
                    className="btn-primary hover-scale focus-brand"
                  >
                    ✅ Salva nota
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => {
                      setShowNoteInput(false);
                      setNoteContent('');
                    }}
                    className="hover-scale focus-brand"
                  >
                    ❌ Annulla
                  </Button>
                </div>
              </div>
            )}

            {questionNotes.length > 0 && (
              <div className="space-y-3">
                {questionNotes.map((note) => (
                  <div key={note.id} className="bg-micha-gray-light/50 p-3 rounded-md border-l-4 border-secondary">
                    <p className="text-sm">{note.content}</p>
                    <span className="text-xs text-muted-foreground">
                      {new Date(note.timestamp).toLocaleString('it-IT')}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </CardContent>

      {/* NAVIGATION FOOTER */}
      <div className="border-t border-secondary/20 p-4 flex flex-col sm:flex-row justify-between gap-3">
        <Button
          variant="outline"
          onClick={onPrevious}
          disabled={currentIndex === 0}
          className="flex items-center justify-center gap-2 hover-scale transition-brand focus-brand disabled:opacity-50"
        >
          <ChevronLeft className="w-4 h-4" />
          <span className="font-semibold text-xs">Precedente</span>
        </Button>
        
        {/* Don't show next button on final card */}
        {!isLastQuestion && (
          <Button
            onClick={onNext}
            disabled={!isQuestionAnswered()}
            className="flex items-center justify-center gap-2 btn-primary hover-scale focus-brand disabled:opacity-50"
            title={!isQuestionAnswered() ? "Completa la risposta per continuare" : ""}
          >
            <span className="font-semibold text-xs">Successiva</span>
            <ChevronRight className="w-4 h-4" />
          </Button>
        )}
      </div>
    </Card>
  );
};

export default FlashCard;