import React from "react";

const Hero: React.FC = () => {
  return (
    <section className="relative overflow-hidden py-12 sm:py-16 lg:py-20 gradient-hero">
      
      {/* DECORATIVE DIAGONAL BANDS - Esattamente 15° come da brand guide */}
      <div className="pointer-events-none absolute -top-10 right-0 h-44 w-2/3 opacity-90">
        {/* Banda principale */}
        <div className="absolute right-10 top-0 h-4 w-2/3 bg-secondary diagonal-band" />
        {/* Banda accent */}
        <div className="absolute right-0 top-6 h-4 w-3/4 bg-accent diagonal-band" />
        {/* Banda grigia */}
        <div className="absolute right-14 top-12 h-4 w-1/2 bg-micha-gray-light diagonal-band" />
        {/* Banda media */}
        <div className="absolute right-8 top-[4.5rem] h-3 w-1/3 bg-micha-blue-medium/50 diagonal-band" />
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="mx-auto max-w-4xl text-center">
          
          {/* MAIN TITLE - All Caps come da brand guide */}
          <h1 className="text-2xl sm:text-3xl lg:text-4xl xl:text-5xl font-bold tracking-wide text-primary mb-4">
            Automazioni fatte per esseri umani
          </h1>
          
          {/* SUBTITLE */}
          <p className="mt-4 text-responsive text-foreground/80 leading-relaxed max-w-2xl mx-auto">
            Questionario interattivo per raccogliere le informazioni utili al tuo preventivo mirato e su misura. 
            <br className="hidden sm:inline" />
            <strong className="text-primary">Zero sbatti, tutto chiaro.</strong>
          </p>

          {/* INFO CARD - Con bordo brand secondo le specifiche */}
          <div className="mt-8 rounded-2xl border-4 border-secondary hover-scale transition-brand">
            <div className="rounded-xl bg-card p-6 sm:p-8 lg:p-10 card-shadow">
              <div className="grid gap-4 sm:gap-6">
                
                {/* MAIN INSTRUCTION */}
                <div className="text-center">
                  <h2 className="text-lg sm:text-xl font-bold text-primary mb-3 uppercase tracking-wide">
                    Come funziona
                  </h2>
                  <p className="text-sm sm:text-base text-foreground/80 leading-relaxed">
                    Scorri le card qui sotto e compila. Puoi aggiungere note personali: 
                    le vedi sempre nel fumetto in basso a destra.
                  </p>
                </div>

                {/* FEATURES GRID */}
                <div className="grid sm:grid-cols-3 gap-4 mt-6">
                  <div className="text-center p-4 rounded-lg bg-micha-gray-light/30">
                    <div className="text-2xl mb-2">📋</div>
                    <h3 className="font-semibold text-primary text-sm uppercase tracking-wide">
                      Compila
                    </h3>
                    <p className="text-xs text-foreground/70 mt-1">
                      Rispondi alle domande
                    </p>
                  </div>
                  
                  <div className="text-center p-4 rounded-lg bg-micha-gray-light/30">
                    <div className="text-2xl mb-2">📝</div>
                    <h3 className="font-semibold text-primary text-sm uppercase tracking-wide">
                      Annota
                    </h3>
                    <p className="text-xs text-foreground/70 mt-1">
                      Aggiungi note personali
                    </p>
                  </div>
                  
                  <div className="text-center p-4 rounded-lg bg-micha-gray-light/30">
                    <div className="text-2xl mb-2">🚀</div>
                    <h3 className="font-semibold text-primary text-sm uppercase tracking-wide">
                      Invia
                    </h3>
                    <p className="text-xs text-foreground/70 mt-1">
                      PDF pronto in un click
                    </p>
                  </div>
                </div>

                {/* CTA BUTTON */}
                <div className="mt-6">
                  <a
                    href="#questionario"
                    className="btn-primary inline-flex items-center gap-2 px-6 py-3 rounded-lg font-bold hover-scale focus-brand"
                  >
                    <span>🎯</span>
                    <span>Inizia il questionario</span>
                  </a>
                </div>
              </div>
            </div>
          </div>

          {/* TRUST INDICATORS */}
          <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-4 sm:gap-8 text-sm text-foreground/60">
            <div className="flex items-center gap-2">
              <span className="text-green-500">✓</span>
              <span>Sicuro e riservato</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-green-500">✓</span>
              <span>Nessun dato venduto</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-green-500">✓</span>
              <span>Solo 5-10 minuti</span>
            </div>
          </div>
        </div>
      </div>

      {/* BOTTOM DECORATIVE BANDS - Sinistra, 15° negativi */}
      <div className="pointer-events-none absolute -bottom-10 left-0 h-32 w-1/2 opacity-90">
        <div className="absolute left-0 bottom-8 h-3 w-2/3 bg-micha-blue-medium/40 diagonal-band-negative" />
        <div className="absolute left-8 bottom-4 h-3 w-3/4 bg-secondary/30 diagonal-band-negative" />
        <div className="absolute left-4 bottom-12 h-2 w-1/2 bg-accent/40 diagonal-band-negative" />
      </div>

      {/* FLOATING ELEMENTS */}
      <div className="pointer-events-none absolute top-1/4 left-1/4 w-2 h-2 bg-secondary rounded-full opacity-60 animate-pulse" />
      <div className="pointer-events-none absolute top-1/3 right-1/3 w-3 h-3 bg-accent rounded-full opacity-40 animate-pulse" style={{ animationDelay: '1s' }} />
      <div className="pointer-events-none absolute bottom-1/4 left-1/3 w-1 h-1 bg-secondary rounded-full opacity-80 animate-pulse" style={{ animationDelay: '2s' }} />
    </section>
  );
};

export default Hero;