import { QuestionnaireSection } from "@/types/questionnaire";

export const questionnaireData: QuestionnaireSection[] = [
  {
    id: "intro",
    title: "📋 QUESTIONARIO TECNICO-OPERATIVO - Automazione Ciclo Fatturazione Passiva 🎨✨",
    questions: [
      {
        id: "intro-1",
        text: "*Caro Salvatore, ho studiato attentamente le specifiche che mi hai inviato e devo dire... raramente ricevo documentazione così dettagliata e precisa. È evidente che avete mappato ogni singolo collo di bottiglia del processo.*\n\n*Per strutturare una proposta che sia davvero cucita su misura per le tue esigenze - e per evitare qualsiasi sorpresa durante l'implementazione - ho bisogno di alcuni dettagli operativi che trasformeranno le tue specifiche in una soluzione funzionante al 100%.* 🚀💼",
        type: "info-only"
      }
    ]
  },
  {
    id: "volumi",
    title: "📊 SEZIONE 1: VOLUMI E IMPATTO ECONOMICO 💰",
    questions: [
      {
        id: "vol-1",
        text: "1. Quanti documenti gestite mediamente ogni mese? 📈",
        type: "text-multiple",
        fields: [
          { label: "DDT", placeholder: "Inserisci numero DDT al mese" },
          { label: "Fatture", placeholder: "Inserisci numero fatture al mese" },
          { label: "Ordini", placeholder: "Inserisci numero ordini al mese" }
        ]
      },
      {
        id: "vol-2",
        text: "2. Quanti sono i fornitori attivi che generano questo flusso documentale? 🏢",
        type: "multiple-choice",
        options: [
          "Fino a 10 fornitori",
          "11-30 fornitori",
          "31-50 fornitori",
          "Oltre 50 fornitori"
        ]
      },
      {
        id: "vol-3",
        text: "3. Quanto tempo stimato viene impiegato ogni settimana dal tuo team per la gestione manuale dell'intero ciclo passivo? ⏰",
        type: "multiple-choice",
        options: [
          "Meno di 5 ore/settimana",
          "5-10 ore/settimana",
          "10-20 ore/settimana", 
          "Oltre 20 ore/settimana",
          "Non abbiamo mai calcolato con precisione"
        ]
      },
      {
        id: "vol-4",
        text: "4. Qual è il tempo massimo accettabile per completare l'associazione automatica fattura-DDT-ordine? ⚡",
        type: "multiple-choice",
        options: [
          "Real-time (entro 15 minuti)",
          "Entro 2 ore dall'arrivo fattura",
          "Entro fine giornata lavorativa",
          "Entro 48 ore"
        ]
      }
    ]
  },
  {
    id: "sistema",
    title: "💻 SEZIONE 2: SISTEMA E ACCESSI TECNICI ⚙️",
    questions: [
      {
        id: "sys-1",
        text: "5. Il vostro gestionale Soldin è installato: 🖥️",
        type: "multiple-choice",
        options: [
          "In cloud (Azure/altro cloud provider)",
          "Su server locale/on-premise",
          "Non sono sicuro"
        ]
      },
      {
        id: "sys-1b",
        text: "E riguardo l'accesso API: 🔗",
        type: "multiple-choice",
        options: [
          "È già attivo e funzionante",
          "Bisogna interfacciarsi con Pragmos per abilitarlo",
          "Non sappiamo se esiste questa possibilità"
        ]
      },
      {
        id: "sys-2",
        text: "6. Chi ha i permessi di amministratore su Soldin e può autorizzare integrazioni esterne? 👤",
        type: "text",
        placeholder: "Nome, ruolo e contatti del responsabile sistema"
      },
      {
        id: "sys-3",
        text: "7. Sapete se Pragmos applica costi aggiuntivi per abilitare integrazioni API su Soldin? E se sì, avete idea dell'ordine di grandezza? 💰",
        type: "multiple-choice",
        options: [
          "Non ci sono costi aggiuntivi",
          "Ci sono costi, ma non sappiamo quanto",
          "Ci sono costi, circa: ________________€",
          "Non ne abbiamo idea, da verificare"
        ]
      },
      {
        id: "sys-4",
        text: "8. Qual è il vostro rapporto attuale con Pragmos per quanto riguarda supporto tecnico e personalizzazioni?",
        type: "multiple-choice",
        options: [
          "Molto collaborativi, supporto eccellente",
          "Disponibili ma con tempi lunghi",
          "Difficili da raggiungere o poco collaborativi", 
          "Non abbiamo mai richiesto personalizzazioni"
        ]
      },
      {
        id: "sys-4-note",
        text: "*📝 Nota: Se mi autorizzi, posso contattare io direttamente Pragmos per tutti i dettagli tecnici, così eviti di perdere tempo in call complicate.* 🤝",
        type: "info-only"
      },
      {
        id: "sys-5",
        text: "9. Oltre a Soldin e SISTEMI, utilizzate altri software che potrebbero dover ricevere dati da questo sistema automatizzato? Ad esempio software per preventivazione/computi, CRM per gestione clienti, sistemi di planning cantieri o altri gestionali specifici? 🔧",
        type: "textarea",
        placeholder: "Descrivi brevemente gli altri software in uso e come potrebbero integrarsi..."
      },
      {
        id: "sys-6",
        text: "10. Per quanto riguarda SISTEMI (il tuo fornitore di fatturazione elettronica): avete accesso programmatico tramite API al portale, oppure accedete solo via interfaccia web?",
        type: "multiple-choice",
        options: [
          "Abbiamo API attive",
          "Solo accesso web al portale",
          "Non lo sappiamo, da verificare"
        ]
      },
      {
        id: "sys-6-note",
        text: "*📝 Nota: Se non ci sono API disponibili, posso interfacciarmi io direttamente con SISTEMI per valutare soluzioni di integrazione alternative.* 🔄",
        type: "info-only"
      }
    ]
  },
  {
    id: "formati",
    title: "📄 SEZIONE 3: FORMATI E DIGITALIZZAZIONE 📱",
    questions: [
      {
        id: "fmt-1",
        text: "11. Dalle tue specifiche ho visto che ricevete DDT cartacei (con i famosi ritardi di 7-10 giorni). Oltre alla copia cartacea, ricevete mai anche una copia digitale dello stesso DDT? 📋",
        type: "text-multiple",
        fields: [
          { label: "DDT", placeholder: "Solo cartacei / Anche digitali (indicare %)" },
          { label: "Ordini e conferme d'ordine", placeholder: "Sempre digitali / Misto (specificare)" },
          { label: "Offerte fornitori allegate agli ordini", placeholder: "Sempre PDF leggibili / A volte immagini scan (specificare)" }
        ]
      },
      {
        id: "fmt-2",
        text: "12. Le offerte fornitori che allegate agli ordini in che formato arrivano esattamente? 📎",
        type: "multiple-choice",
        options: [
          "PDF nativi (creati digitalmente, testo selezionabile)",
          "PDF scannerizzati (da carta, come immagini)",
          "File Word/Excel",
          "Immagini (JPG, PNG)",
          "Misto, dipende dal fornitore"
        ]
      },
      {
        id: "fmt-3",
        text: "13. I vostri fornitori principali hanno formati documenti standardizzati o ognuno usa il proprio template? 📝",
        type: "multiple-choice",
        options: [
          "Formato abbastanza standardizzato (80%+ simili)",
          "2-3 formati principali ricorrenti",
          "Ogni fornitore ha il suo formato specifico",
          "Molto variabile, difficile da prevedere"
        ]
      }
    ]
  },
  {
    id: "crescita",
    title: "📈 SEZIONE 4: CRESCITA E PERFORMANCE 🚀",
    questions: [
      {
        id: "gro-1",
        text: "14. Prevedete crescita del volume documenti nei prossimi 2 anni? 📊",
        type: "multiple-choice",
        options: [
          "Volume stabile",
          "Crescita moderata (20-30%)",
          "Crescita significativa (50-70%)",
          "Crescita importante (oltre 100%)"
        ]
      },
      {
        id: "gro-2",
        text: "15. Ci sono momenti specifici del mese o dell'anno con picchi di carico documentale? 📅",
        type: "multiple-choice",
        options: [
          "Fine mese (chiusure contabili)",
          "Periodi stagionali specifici: ________________",
          "Flusso abbastanza costante tutto l'anno",
          "Dipende dai progetti in corso"
        ]
      },
      {
        id: "gro-3",
        text: "16. Che livello di precisione ti aspetti dall'automazione? 🎯",
        type: "multiple-choice",
        options: [
          "Almeno 95% di documenti processati correttamente",
          "Almeno 90% va bene, l'importante è che funzioni",
          "Anche 80-85% se il resto viene segnalato per verifica manuale",
          "Da valutare in base ai risultati dei primi test"
        ]
      }
    ]
  },
  {
    id: "organizzazione",
    title: "👥 SEZIONE 5: ORGANIZZAZIONE E RESPONSABILITÀ 👔",
    questions: [
      {
        id: "org-1",
        text: "17. Quale ruolo aziendale si occuperà della gestione quotidiana del sistema automatizzato? (Mi serve per capire che tipo di interfaccia costruire: semplice per non tecnici o più dettagliata per chi ha competenze IT) 💼",
        type: "textarea",
        placeholder: "Descrivi il ruolo, le competenze tecniche e l'esperienza con software gestionali..."
      },
      {
        id: "org-2", 
        text: "18. Quale ruolo prenderà le decisioni operative sul sistema una volta attivo? (Per definire il livello di accesso e responsabilità) 🎯",
        type: "textarea",
        placeholder: "Specifica chi avrà l'autorità per modifiche, configurazioni e decisioni sul sistema..."
      }
    ]
  },
  {
    id: "aspettative",
    title: "🎯 SEZIONE 6: ASPETTATIVE E VISIONE FUTURA 🌟",
    questions: [
      {
        id: "asp-1",
        text: "19. Cosa cambierebbe concretamente nella tua operatività quotidiana se questo sistema funzionasse al 100%? ✨",
        type: "textarea",
        placeholder: "Descrivi l'impatto pratico: tempo risparmiato, processi eliminati, benefici concreti..."
      },
      {
        id: "asp-2",
        text: "20. Cosa NON deve assolutamente accadere durante l'implementazione? ⚠️",
        type: "checkbox",
        options: [
          "Interruzioni del lavoro quotidiano",
          "Costi imprevisti durante il progetto",
          "Tempi di implementazione troppo lunghi",
          "Perdita o corruzione di dati esistenti",
          "Complicazioni con software già in uso",
          "Altro: ________________________________________________"
        ]
      },
      {
        id: "asp-3",
        text: "21. Hai accennato che potremmo valutare anche altri fronti dove supportarvi. In quale area aziendale ti piacerebbe integrare soluzioni innovative? 🚀",
        type: "checkbox",
        required: false,
        options: [
          "Marketing (automazioni email, gestione lead, campagne personalizzate)",
          "Customer Care (chatbot assistenza, FAQ automatiche, gestione reclami)",
          "Uso interno (assistente personale, gestione agenda, promemoria automatici)",
          "Amministrazione (analisi documenti, reportistica automatica)",
          "Gestione progetti e cantieri (planning, monitoraggio avanzamento)",
          "Al momento solo il ciclo fatturazione passiva",
          "Altro: ________________________________________________"
        ]
      }
    ]
  },
  {
    id: "autorizzazioni",
    title: "🤝 AUTORIZZAZIONE CONTATTI DIRETTI 📞",
    questions: [
      {
        id: "auth-1",
        text: "Per accelerare i tempi e evitarti perdite di tempo in call tecniche: Se mi autorizzi, posso contattare direttamente: 🚀",
        type: "checkbox",
        options: [
          "Pragmos (software house Soldin) per dettagli tecnici API e integrazioni",
          "SISTEMI per verificare modalità di accesso programmatico ai dati SDI"
        ],
        required: false
      },
      {
        id: "auth-2",
        text: "Referente Pragmos (compila solo se hai autorizzato il contatto): 👤",
        type: "text-multiple",
        fields: [
          { label: "Numero di telefono", placeholder: "Es. +39 XXX XXXXXXX", required: false },
          { label: "Email", placeholder: "Es. supporto@pragmos.it", required: false },
          { label: "Nome del referente", placeholder: "Es. Mario Rossi", required: false }
        ],
        conditionalRequired: {
          dependsOn: "auth-1",
          value: "Pragmos (software house Soldin) per dettagli tecnici API e integrazioni"
        },
        conditionalDisplay: {
          dependsOn: "auth-1",
          value: "Pragmos (software house Soldin) per dettagli tecnici API e integrazioni"
        }
      }
    ]
  },
  {
    id: "conclusioni",
    title: "📝 NOTE AGGIUNTIVE E CONCLUSIONI ✨",
    questions: [
      {
        id: "conc-1",
        text: "Spazio per osservazioni, vincoli particolari o dettagli specifici della tua realtà aziendale: 📋",
        type: "textarea",
        placeholder: "Aggiungi qualsiasi informazione che ritieni importante per il progetto..."
      },
      {
        id: "conc-final",
        text: "*🎉 Grazie per il tempo dedicato a questo questionario! Come avrai notato, ogni domanda è progettata per trasformare le tue specifiche tecniche in una soluzione concreta e funzionante. Così non ci saranno sorprese, non ci saranno costi nascosti.*\n\n*🎯 L'obiettivo è semplice: ti restituisco le ore che oggi sprechi in controlli manuali.*\n\n*📞 Una volta ricevute le risposte, organizzeremo la call di presentazione dove ti mostrerò la soluzione specifica per il tuo caso, con tempi e costi definitivi.* 🚀",
        type: "info-only"
      }
    ]
  }
];