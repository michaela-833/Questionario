import React, { useState, useMemo } from 'react';
import FlashCard from '@/components/FlashCard';
import NoteBubble from '@/components/NoteBubble';
import ActionButtons from '@/components/ActionButtons';
import Footer from '@/components/Footer';
import Header from '@/components/Header';
import Hero from '@/components/Hero';
import { questionnaireData } from '@/data/questionnaireData';
import { Note, Question } from '@/types/questionnaire';

const Index = () => {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [notes, setNotes] = useState<Note[]>([]);
  const [answers, setAnswers] = useState<Record<string, string | string[] | Record<string, string>>>({});

  // Flatten all questions from all sections and filter conditionally displayed ones
  const allQuestions = useMemo(() => {
    const questions: Question[] = [];
    questionnaireData.forEach(section => {
      section.questions.forEach(question => {
        questions.push(question);
      });
    });
    return questions;
  }, []);

  // Filter questions based on conditional display
  const visibleQuestions = useMemo(() => {
    return allQuestions.filter(question => {
      if (!question.conditionalDisplay) return true;
      
      const dependentValue = answers[question.conditionalDisplay.dependsOn];
      if (Array.isArray(dependentValue)) {
        return dependentValue.includes(question.conditionalDisplay.value);
      }
      return dependentValue === question.conditionalDisplay.value;
    });
  }, [allQuestions, answers]);

  // Adjust current index if current question is no longer visible
  React.useEffect(() => {
    if (currentQuestionIndex >= visibleQuestions.length && visibleQuestions.length > 0) {
      setCurrentQuestionIndex(visibleQuestions.length - 1);
    }
  }, [visibleQuestions.length, currentQuestionIndex]);

  const addNote = (questionId: string, content: string) => {
    const newNote: Note = {
      id: Date.now().toString(),
      sectionId: questionId,
      content,
      timestamp: Date.now()
    };
    setNotes(prev => [...prev, newNote]);
  };

  const updateNote = (noteId: string, content: string) => {
    setNotes(prev => prev.map(note => 
      note.id === noteId ? { ...note, content, timestamp: Date.now() } : note
    ));
  };

  const deleteNote = (noteId: string) => {
    setNotes(prev => prev.filter(note => note.id !== noteId));
  };

  const handleAnswerChange = (questionId: string, answer: string | string[] | Record<string, string>) => {
    setAnswers(prev => ({ ...prev, [questionId]: answer }));
    
    // Update the question object with the answer
    const question = visibleQuestions.find(q => q.id === questionId);
    if (question) {
      question.answer = answer;
    }
  };

  const nextQuestion = () => {
    if (currentQuestionIndex < visibleQuestions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
    }
  };

  const previousQuestion = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(prev => prev - 1);
    }
  };

  const isLastQuestion = currentQuestionIndex === visibleQuestions.length - 1;
  const currentQuestion = visibleQuestions[currentQuestionIndex];
  
  // Set answer from stored answers
  if (currentQuestion && answers[currentQuestion.id]) {
    currentQuestion.answer = answers[currentQuestion.id];
  }

  // Check if it's the first question (intro)
  const isFirstQuestion = currentQuestionIndex === 0;

  // Get conditional dependencies for conditional required fields
  const conditionalDependencies = useMemo(() => {
    const deps: Record<string, string | string[]> = {};
    Object.entries(answers).forEach(([questionId, answer]) => {
      if (typeof answer === 'string' || Array.isArray(answer)) {
        deps[questionId] = answer;
      } else if (typeof answer === 'object') {
        // For multi-field answers, we use a simplified representation for dependencies
        deps[questionId] = Object.values(answer).join(' ');
      }
    });
    return deps;
  }, [answers]);

  // Progress calculation
  const progress = ((currentQuestionIndex + 1) / allQuestions.length) * 100;
  const answeredQuestions = Object.keys(answers).length;

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      
      {/* BACKGROUND GRADIENT - Brand hero style */}
      <div className="fixed inset-0 gradient-hero opacity-30 pointer-events-none" />
      
      {/* FLOATING BACKGROUND ELEMENTS */}
      <div className="fixed top-1/4 left-1/4 w-2 h-2 bg-secondary rounded-full opacity-20 animate-pulse pointer-events-none" />
      <div className="fixed top-1/3 right-1/3 w-3 h-3 bg-accent rounded-full opacity-15 animate-pulse pointer-events-none" style={{ animationDelay: '1s' }} />
      <div className="fixed bottom-1/4 left-1/3 w-1 h-1 bg-secondary rounded-full opacity-25 animate-pulse pointer-events-none" style={{ animationDelay: '2s' }} />
      
      {/* MAIN LAYOUT */}
      <div className="relative z-10">
        <Header />
        <Hero />

        {/* PROGRESS BAR - Sostituita con quella dello screen allegato */}
        <div className="sticky top-16 z-40 bg-background/95 backdrop-blur-sm border-b border-secondary/20">
          <div className="container mx-auto px-4 py-2">
            <div className="bg-primary text-primary-foreground px-4 py-2 rounded-lg flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-sm font-bold uppercase tracking-wide">
                  📋 {getSectionTitle(currentQuestion?.id || '')}
                </span>
              </div>
              <div className="bg-primary-foreground/20 px-3 py-1 rounded-full text-xs font-bold">
                {currentQuestionIndex + 1} di {visibleQuestions.length}
              </div>
            </div>
          </div>
        </div>

        {/* MAIN QUESTIONNAIRE SECTION */}
        <main id="questionario" className="container mx-auto space-y-8 py-6 sm:py-8 lg:py-12 relative">
          
          {/* SECTION INDICATOR - Solo se non siamo nell'intro */}
          {!isFirstQuestion && (
            <div className="text-center mb-6">
              <div className="inline-flex items-center gap-2 bg-card px-4 py-2 rounded-full border border-secondary/20 card-shadow">
                <div className="w-2 h-2 bg-secondary rounded-full animate-pulse" />
                <span className="text-sm font-semibold text-primary uppercase tracking-wide">
                  {getSectionTitle(currentQuestion?.id || '')}
                </span>
              </div>
            </div>
          )}

          {/* FLASHCARD COMPONENT */}
          {currentQuestion && (
            <FlashCard
              question={currentQuestion}
              currentIndex={currentQuestionIndex}
              totalQuestions={visibleQuestions.length}
              onNext={nextQuestion}
              onPrevious={previousQuestion}
              notes={notes}
              onAddNote={addNote}
              onAnswerChange={handleAnswerChange}
              showNotes={!isFirstQuestion}
              conditionalDependencies={conditionalDependencies}
              finalActions={isLastQuestion && currentQuestion?.type === 'info-only' ? (
                <div className="space-y-4">
                  {/* COMPLETION STATS */}
                  <div className="bg-micha-gray-light/30 p-4 rounded-lg mb-4">
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-center">
                      <div>
                        <div className="text-lg font-bold text-secondary">{answeredQuestions}</div>
                        <div className="text-xs text-muted-foreground uppercase tracking-wide">Risposte</div>
                      </div>
                      <div>
                        <div className="text-lg font-bold text-accent">{notes.length}</div>
                        <div className="text-xs text-muted-foreground uppercase tracking-wide">Note</div>
                      </div>
                      <div>
                        <div className="text-lg font-bold text-primary">100%</div>
                        <div className="text-xs text-muted-foreground uppercase tracking-wide">Completato</div>
                      </div>
                      <div>
                        <div className="text-lg font-bold text-secondary">✓</div>
                        <div className="text-xs text-muted-foreground uppercase tracking-wide">Pronto</div>
                      </div>
                    </div>
                  </div>
                  
                  {/* ACTION BUTTONS */}
                  <ActionButtons
                    notes={notes}
                    answers={answers}
                    questions={allQuestions} // Use all questions for PDF generation
                    compact
                  />
                </div>
              ) : undefined}
            />
          )}

          {/* QUICK NAVIGATION RIMOSSA - Non riflette correttamente il movimento delle card */}
        </main>

        {/* NOTE BUBBLE - Floating assistant */}
        <NoteBubble
          notes={notes}
          onUpdateNote={updateNote}
          onDeleteNote={deleteNote}
        />
        
        {/* FOOTER */}
        <Footer />
      </div>
    </div>
  );
};

// Helper function to get section title from question ID
const getSectionTitle = (questionId: string): string => {
  const sectionMap: Record<string, string> = {
    'vol-': '📊 Volumi e Impatto',
    'sys-': '💻 Sistema e Accessi',
    'fmt-': '📄 Formati e Digital',
    'gro-': '📈 Crescita e Performance',
    'org-': '👥 Organizzazione',
    'asp-': '🎯 Aspettative e Visione',
    'auth-': '🤝 Autorizzazioni',
    'conc-': '📝 Conclusioni'
  };
  
  for (const [prefix, title] of Object.entries(sectionMap)) {
    if (questionId.startsWith(prefix)) {
      return title;
    }
  }
  
  return '📋 Questionario';
};

export default Index;