export interface QuestionnaireSection {
  id: string;
  title: string;
  questions: Question[];
}

export interface Question {
  id: string;
  text: string;
  type: 'multiple-choice' | 'text' | 'checkbox' | 'textarea' | 'text-multiple' | 'info-only';
  options?: string[];
  fields?: Array<{
    label: string;
    placeholder: string;
    required?: boolean;
  }>;
  required?: boolean;
  conditionalRequired?: {
    dependsOn: string;
    value: string;
  };
  conditionalDisplay?: {
    dependsOn: string;
    value: string;
  };
  value?: string | string[] | Record<string, string>;
  answer?: string | string[] | Record<string, string>;
}

export interface Note {
  id: string;
  sectionId: string;
  content: string;
  timestamp: number;
}