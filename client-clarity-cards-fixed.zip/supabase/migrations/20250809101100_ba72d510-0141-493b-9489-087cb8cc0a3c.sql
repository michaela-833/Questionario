-- Create public bucket for questionnaire PDFs
insert into storage.buckets (id, name, public)
values ('questionari', 'questionari', true)
on conflict (id) do update set public = true;

-- Enable RLS on storage.objects is managed by Supabase, we only add policies
-- Allow anyone to read files from the public bucket
create policy "Public can read questionnaire PDFs"
  on storage.objects
  for select
  using (bucket_id = 'questionari');

-- Allow anyone (including anon) to upload PDFs to the specific bucket
create policy "Anyone can upload questionnaire PDFs"
  on storage.objects
  for insert
  with check (bucket_id = 'questionari');

-- Allow overriding existing files within the bucket (update) to support upsert=true
create policy "Anyone can update questionnaire PDFs in bucket"
  on storage.objects
  for update
  using (bucket_id = 'questionari')
  with check (bucket_id = 'questionari');

-- (Optional) Disallow deletes by default (no delete policy). If needed later, we can add a restricted delete policy.
